
const content = {
  en: "<h2>Welcome</h2><p>We specialize in interior construction work.</p>",
  fr: "<h2>Bienvenue</h2><p>Nous sommes spécialisés dans les travaux de construction intérieure.</p>",
  nl: "<h2>Welkom</h2><p>Wij zijn gespecialiseerd in binnenbouwwerkzaamheden.</p>"
};

const main = document.getElementById('content');
const select = document.getElementById('languageSwitcher');

function updateContent() {
  main.innerHTML = content[select.value];
}

select.addEventListener('change', updateContent);
updateContent();
